Fractal Viewer / Generator for FooCity project

To execute download a copy of the Java Runtime Environment (JRE) or Java Development Kit (JDK) from:

http://www.oracle.com/technetwork/java/javase/downloads/index.html

Double click the .jar file to execute the program. Either load one of the map files or generate your own.